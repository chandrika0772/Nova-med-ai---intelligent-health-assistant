-- Add user_id column to patients table for ownership tracking
ALTER TABLE patients ADD COLUMN IF NOT EXISTS user_id UUID;

-- Add user_id column to consultations table for ownership tracking
ALTER TABLE consultations ADD COLUMN IF NOT EXISTS user_id UUID;

-- Create index for faster RLS policy evaluation
CREATE INDEX IF NOT EXISTS idx_patients_user_id ON patients(user_id);
CREATE INDEX IF NOT EXISTS idx_consultations_user_id ON consultations(user_id);

-- Drop the insecure RLS policies
DROP POLICY IF EXISTS "patients_are_accessible_by_anyone" ON patients;
DROP POLICY IF EXISTS "patients_can_be_inserted" ON patients;
DROP POLICY IF EXISTS "consultations_are_accessible_by_anyone" ON consultations;
DROP POLICY IF EXISTS "consultations_can_be_inserted" ON consultations;

-- Patients: Only authenticated users can manage their own records
CREATE POLICY "users_select_own_patients" ON patients
  FOR SELECT TO authenticated USING (auth.uid() = user_id);

CREATE POLICY "users_insert_own_patients" ON patients
  FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

CREATE POLICY "users_update_own_patients" ON patients
  FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

CREATE POLICY "users_delete_own_patients" ON patients
  FOR DELETE TO authenticated USING (auth.uid() = user_id);

-- Consultations: Only authenticated users can manage their own records
CREATE POLICY "users_select_own_consultations" ON consultations
  FOR SELECT TO authenticated USING (auth.uid() = user_id);

CREATE POLICY "users_insert_own_consultations" ON consultations
  FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

CREATE POLICY "users_update_own_consultations" ON consultations
  FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

CREATE POLICY "users_delete_own_consultations" ON consultations
  FOR DELETE TO authenticated USING (auth.uid() = user_id);

-- For symptom_analytics, allow anyone to read but only authenticated users to insert/update
DROP POLICY IF EXISTS "analytics_are_readable" ON symptom_analytics;

CREATE POLICY "anyone_read_analytics" ON symptom_analytics
  FOR SELECT USING (true);

CREATE POLICY "authenticated_insert_analytics" ON symptom_analytics
  FOR INSERT TO authenticated WITH CHECK (true);

CREATE POLICY "authenticated_update_analytics" ON symptom_analytics
  FOR UPDATE TO authenticated USING (true) WITH CHECK (true);