CREATE TABLE IF NOT EXISTS patients (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name VARCHAR(255) NOT NULL,
  age INTEGER NOT NULL,
  email VARCHAR(255),
  phone VARCHAR(20),
  medical_history TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

ALTER TABLE patients ENABLE ROW LEVEL SECURITY;

CREATE POLICY "patients_are_accessible_by_anyone" ON patients
  FOR SELECT USING (true);

CREATE POLICY "patients_can_be_inserted" ON patients
  FOR INSERT WITH CHECK (true);

CREATE TABLE IF NOT EXISTS consultations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id UUID REFERENCES patients(id) ON DELETE CASCADE,
  symptoms TEXT[] NOT NULL,
  additional_notes TEXT,
  analysis_results JSONB,
  severity VARCHAR(20),
  risk_level VARCHAR(20),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

ALTER TABLE consultations ENABLE ROW LEVEL SECURITY;

CREATE POLICY "consultations_are_accessible_by_anyone" ON consultations
  FOR SELECT USING (true);

CREATE POLICY "consultations_can_be_inserted" ON consultations
  FOR INSERT WITH CHECK (true);

CREATE TABLE IF NOT EXISTS symptom_analytics (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  symptom_name VARCHAR(255) NOT NULL,
  count INTEGER DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(symptom_name)
);

ALTER TABLE symptom_analytics ENABLE ROW LEVEL SECURITY;

CREATE POLICY "analytics_are_readable" ON symptom_analytics
  FOR SELECT USING (true);