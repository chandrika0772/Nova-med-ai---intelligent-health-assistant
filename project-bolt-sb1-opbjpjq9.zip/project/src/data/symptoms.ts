export interface Symptom {
  id: string;
  label: string;
  icon: string;
  category: string;
}

export interface FeverType {
  name: string;
  probability: number;
  description: string;
  symptoms: string[];
}

export interface Diagnosis {
  possibleConditions: string[];
  feverTypes: FeverType[];
  hasFever: boolean;
  suggestions: string[];
  precautions: string[];
  medicines: string[];
  severity: "mild" | "moderate" | "severe";
  seekUrgentCare: boolean;
}

export const SYMPTOMS: Symptom[] = [
  { id: "fever", label: "Fever / High Temperature", icon: "Thermometer", category: "general" },
  { id: "headache", label: "Headache", icon: "Brain", category: "general" },
  { id: "cough", label: "Cough", icon: "Wind", category: "respiratory" },
  { id: "sore_throat", label: "Sore Throat", icon: "Mic", category: "respiratory" },
  { id: "runny_nose", label: "Runny Nose", icon: "Droplets", category: "respiratory" },
  { id: "body_ache", label: "Body Ache / Muscle Pain", icon: "Activity", category: "general" },
  { id: "fatigue", label: "Fatigue / Weakness", icon: "Battery", category: "general" },
  { id: "nausea", label: "Nausea / Vomiting", icon: "AlertCircle", category: "digestive" },
  { id: "diarrhea", label: "Diarrhea", icon: "Waves", category: "digestive" },
  { id: "abdominal_pain", label: "Abdominal Pain", icon: "Circle", category: "digestive" },
  { id: "chills", label: "Chills / Shivering", icon: "Snowflake", category: "general" },
  { id: "sweating", label: "Excessive Sweating", icon: "Droplet", category: "general" },
  { id: "rash", label: "Skin Rash", icon: "Zap", category: "skin" },
  { id: "joint_pain", label: "Joint Pain", icon: "Bone", category: "musculoskeletal" },
  { id: "chest_pain", label: "Chest Pain", icon: "Heart", category: "cardiovascular" },
  { id: "shortness_breath", label: "Shortness of Breath", icon: "Wind", category: "respiratory" },
  { id: "loss_taste_smell", label: "Loss of Taste/Smell", icon: "Eye", category: "neurological" },
  { id: "dizziness", label: "Dizziness", icon: "RefreshCw", category: "neurological" },
  { id: "eye_redness", label: "Red / Watery Eyes", icon: "Eye", category: "sensory" },
  { id: "loss_appetite", label: "Loss of Appetite", icon: "Coffee", category: "digestive" },
];

export function analyzeSymptomsData(symptomIds: string[], additionalText: string): Diagnosis {
  const allInput = [...symptomIds, additionalText.toLowerCase()];
  const hasSymptom = (id: string) => symptomIds.includes(id);
  const textIncludes = (term: string) => additionalText.toLowerCase().includes(term);

  const hasFever = hasSymptom("fever") || textIncludes("fever") || textIncludes("temperature") || textIncludes("hot");
  const hasChills = hasSymptom("chills") || textIncludes("chill") || textIncludes("shiver");
  const hasBodyAche = hasSymptom("body_ache") || textIncludes("body ache") || textIncludes("muscle");
  const hasHeadache = hasSymptom("headache") || textIncludes("headache") || textIncludes("head pain");
  const hasCough = hasSymptom("cough") || textIncludes("cough");
  const hasRash = hasSymptom("rash") || textIncludes("rash") || textIncludes("spots");
  const hasJointPain = hasSymptom("joint_pain") || textIncludes("joint");
  const hasNausea = hasSymptom("nausea") || textIncludes("nausea") || textIncludes("vomit");
  const hasDiarrhea = hasSymptom("diarrhea") || textIncludes("diarrhea");
  const hasAbdominalPain = hasSymptom("abdominal_pain") || textIncludes("stomach") || textIncludes("abdomen");
  const hasLossTaste = hasSymptom("loss_taste_smell") || textIncludes("taste") || textIncludes("smell");
  const hasSoreThroat = hasSymptom("sore_throat") || textIncludes("throat");
  const hasBreathing = hasSymptom("shortness_breath") || textIncludes("breath") || textIncludes("breathing");
  const hasFatigue = hasSymptom("fatigue") || textIncludes("tired") || textIncludes("weak") || textIncludes("fatigue");
  const hasSweating = hasSymptom("sweating") || textIncludes("sweat");
  const hasEyeRedness = hasSymptom("eye_redness") || textIncludes("eye");

  const feverTypes: FeverType[] = [];

  // Dengue
  if (hasFever) {
    let dengueScore = 0;
    if (hasFever) dengueScore += 25;
    if (hasBodyAche) dengueScore += 20;
    if (hasHeadache) dengueScore += 15;
    if (hasRash) dengueScore += 25;
    if (hasJointPain) dengueScore += 20;
    if (hasNausea) dengueScore += 10;
    if (hasEyeRedness) dengueScore += 15;
    if (dengueScore >= 30) {
      feverTypes.push({
        name: "Dengue Fever",
        probability: Math.min(dengueScore, 90),
        description: "Dengue is a mosquito-borne viral infection causing severe flu-like symptoms.",
        symptoms: ["High fever", "Severe headache", "Pain behind eyes", "Joint and muscle pain", "Rash"],
      });
    }
  }

  // Malaria
  if (hasFever) {
    let malariaScore = 0;
    if (hasFever) malariaScore += 25;
    if (hasChills) malariaScore += 30;
    if (hasSweating) malariaScore += 20;
    if (hasHeadache) malariaScore += 15;
    if (hasNausea) malariaScore += 10;
    if (hasFatigue) malariaScore += 10;
    if (malariaScore >= 35) {
      feverTypes.push({
        name: "Malaria",
        probability: Math.min(malariaScore, 88),
        description: "Malaria is a life-threatening disease caused by parasites transmitted through infected mosquitoes.",
        symptoms: ["Cyclical high fever", "Intense chills", "Profuse sweating", "Headache", "Nausea"],
      });
    }
  }

  // Typhoid
  if (hasFever) {
    let typhoidScore = 0;
    if (hasFever) typhoidScore += 20;
    if (hasAbdominalPain) typhoidScore += 25;
    if (hasDiarrhea) typhoidScore += 20;
    if (hasHeadache) typhoidScore += 15;
    if (hasFatigue) typhoidScore += 10;
    if (hasNausea) typhoidScore += 10;
    if (typhoidScore >= 30) {
      feverTypes.push({
        name: "Typhoid Fever",
        probability: Math.min(typhoidScore, 85),
        description: "Typhoid fever is a bacterial infection that spreads through contaminated food and water.",
        symptoms: ["Sustained high fever", "Abdominal pain", "Headache", "Weakness", "Constipation or diarrhea"],
      });
    }
  }

  // Viral Fever
  if (hasFever) {
    let viralScore = 0;
    if (hasFever) viralScore += 20;
    if (hasBodyAche) viralScore += 15;
    if (hasFatigue) viralScore += 15;
    if (hasCough) viralScore += 10;
    if (hasSoreThroat) viralScore += 10;
    if (hasHeadache) viralScore += 10;
    if (viralScore >= 25) {
      feverTypes.push({
        name: "Viral Fever",
        probability: Math.min(viralScore + 10, 82),
        description: "A common condition caused by viral infections affecting the body.",
        symptoms: ["Moderate to high fever", "Body ache", "Fatigue", "Headache", "Cough and cold"],
      });
    }
  }

  // Influenza (Flu)
  if (hasFever) {
    let fluScore = 0;
    if (hasFever) fluScore += 20;
    if (hasBodyAche) fluScore += 20;
    if (hasCough) fluScore += 20;
    if (hasFatigue) fluScore += 15;
    if (hasHeadache) fluScore += 15;
    if (hasChills) fluScore += 15;
    if (hasSoreThroat) fluScore += 10;
    if (fluScore >= 40) {
      feverTypes.push({
        name: "Influenza (Flu)",
        probability: Math.min(fluScore, 87),
        description: "Influenza is a contagious respiratory illness caused by influenza viruses.",
        symptoms: ["High fever", "Severe body aches", "Dry cough", "Chills", "Extreme fatigue"],
      });
    }
  }

  // COVID-19
  if (hasFever) {
    let covidScore = 0;
    if (hasFever) covidScore += 20;
    if (hasLossTaste) covidScore += 35;
    if (hasCough) covidScore += 15;
    if (hasBreathing) covidScore += 20;
    if (hasFatigue) covidScore += 15;
    if (hasBodyAche) covidScore += 10;
    if (covidScore >= 25) {
      feverTypes.push({
        name: "COVID-19",
        probability: Math.min(covidScore, 85),
        description: "COVID-19 is a respiratory illness caused by the SARS-CoV-2 coronavirus.",
        symptoms: ["Fever", "Dry cough", "Loss of taste/smell", "Shortness of breath", "Fatigue"],
      });
    }
  }

  // Chikungunya
  if (hasFever) {
    let chikScore = 0;
    if (hasFever) chikScore += 20;
    if (hasJointPain) chikScore += 35;
    if (hasRash) chikScore += 20;
    if (hasHeadache) chikScore += 15;
    if (hasBodyAche) chikScore += 15;
    if (chikScore >= 35) {
      feverTypes.push({
        name: "Chikungunya",
        probability: Math.min(chikScore, 83),
        description: "Chikungunya is a viral disease transmitted to humans by infected mosquitoes.",
        symptoms: ["Sudden onset fever", "Severe joint pain", "Muscle pain", "Rash", "Headache"],
      });
    }
  }

  // Heat Fever / Heat Stroke
  const hotText = textIncludes("hot") || textIncludes("heat") || textIncludes("sun");
  if (hasFever && (hasSweating || hotText)) {
    let heatScore = 0;
    if (hasFever) heatScore += 20;
    if (hasSweating) heatScore += 25;
    if (hasSymptom("dizziness") || textIncludes("dizzy")) heatScore += 25;
    if (hotText) heatScore += 20;
    if (heatScore >= 35) {
      feverTypes.push({
        name: "Heat Fever / Heat Stroke",
        probability: Math.min(heatScore, 78),
        description: "Condition caused by overheating of the body due to prolonged exposure to high temperatures.",
        symptoms: ["High body temperature", "Excessive sweating", "Dizziness", "Nausea", "Rapid heartbeat"],
      });
    }
  }

  // Bacterial Fever
  if (hasFever) {
    let bacterialScore = 0;
    if (hasFever) bacterialScore += 20;
    if (hasSoreThroat) bacterialScore += 20;
    if (hasAbdominalPain) bacterialScore += 15;
    if (hasDiarrhea) bacterialScore += 15;
    if (hasFatigue) bacterialScore += 10;
    if (hasNausea) bacterialScore += 10;
    if (bacterialScore >= 35) {
      feverTypes.push({
        name: "Bacterial Infection Fever",
        probability: Math.min(bacterialScore, 75),
        description: "Fever caused by bacterial infections in the body requiring antibiotic treatment.",
        symptoms: ["Persistent high fever", "Sore throat", "Abdominal pain", "Diarrhea", "Fatigue"],
      });
    }
  }

  // Common Cold with Fever
  if (hasFever || hasCough || hasSoreThroat) {
    let coldScore = 0;
    if (hasCough) coldScore += 25;
    if (hasSoreThroat) coldScore += 25;
    if (hasSymptom("runny_nose") || textIncludes("runny") || textIncludes("nose")) coldScore += 25;
    if (hasFever) coldScore += 15;
    if (hasHeadache) coldScore += 10;
    if (coldScore >= 35) {
      feverTypes.push({
        name: "Common Cold with Fever",
        probability: Math.min(coldScore, 80),
        description: "A mild viral infection of the upper respiratory tract, sometimes accompanied by low-grade fever.",
        symptoms: ["Runny nose", "Sore throat", "Cough", "Mild fever", "Sneezing"],
      });
    }
  }

  feverTypes.sort((a, b) => b.probability - a.probability);

  const totalSymptoms = symptomIds.length + (additionalText.trim().length > 0 ? 1 : 0);
  const hasSevere = hasBreathing || hasSymptom("chest_pain") || textIncludes("chest pain") || textIncludes("unconscious");

  const severity: "mild" | "moderate" | "severe" =
    hasSevere || totalSymptoms >= 8 ? "severe" : totalSymptoms >= 4 ? "moderate" : "mild";

  const suggestions: string[] = [];
  const precautions: string[] = [];
  const medicines: string[] = [];

  // Suggestions
  suggestions.push("Stay well hydrated — drink plenty of water, coconut water, or ORS solutions.");
  if (hasFever) suggestions.push("Monitor your body temperature regularly every 4-6 hours.");
  if (hasBodyAche || hasJointPain) suggestions.push("Rest and avoid strenuous physical activity.");
  if (hasCough || hasSoreThroat) suggestions.push("Avoid cold drinks and stay in a warm environment.");
  if (hasNausea || hasDiarrhea || hasAbdominalPain) suggestions.push("Eat light, easily digestible food — rice, bananas, toast.");
  if (hasLossTaste) suggestions.push("Try warm soups and nutritious foods even if taste is impaired.");
  suggestions.push("Get adequate sleep — aim for 8-10 hours during illness.");
  if (hasFever && feverTypes.some(f => f.name === "Dengue Fever" || f.name === "Malaria")) {
    suggestions.push("Avoid mosquito exposure — use mosquito nets, repellents, and wear full-sleeve clothing.");
  }

  // Precautions
  precautions.push("Wash hands frequently with soap and water for at least 20 seconds.");
  if (hasFever || hasCough) precautions.push("Wear a mask to prevent spreading infection to others.");
  precautions.push("Avoid close contact with elderly people and young children while sick.");
  precautions.push("Do not self-medicate with antibiotics without a doctor's prescription.");
  if (hasFever) precautions.push("Avoid cold showers or ice baths; use lukewarm sponging to reduce fever.");
  if (hasBreathing || hasSymptom("chest_pain")) precautions.push("Seek emergency medical care immediately if breathing worsens.");
  precautions.push("Keep your environment clean and well-ventilated.");
  if (hasNausea || hasDiarrhea) precautions.push("Avoid spicy, oily, and heavy foods until symptoms subside.");

  // Medicine suggestions
  if (hasFever) {
    medicines.push("Paracetamol (Acetaminophen) 500mg — for fever reduction (as per doctor's advice).");
    medicines.push("ORS (Oral Rehydration Solution) — to prevent dehydration.");
  }
  if (hasHeadache) medicines.push("Ibuprofen (consult doctor before use) — for headache and body pain.");
  if (hasCough) medicines.push("Cough syrup (Dextromethorphan-based) — for dry cough relief.");
  if (hasSoreThroat) medicines.push("Throat lozenges or warm honey-ginger drink — for sore throat.");
  if (hasNausea) medicines.push("ORS and light diet — for nausea management.");
  if (hasBodyAche || hasJointPain) medicines.push("Paracetamol or Ibuprofen — for pain relief (consult doctor).");
  medicines.push("Vitamin C and Zinc supplements — to boost immunity.");
  medicines.push("IMPORTANT: All medicines should be taken ONLY as directed by a registered doctor.");

  const conditions: string[] = [];
  if (hasFever) conditions.push("Febrile Illness");
  if (hasCough && hasSoreThroat) conditions.push("Upper Respiratory Tract Infection (URTI)");
  if (hasDiarrhea && hasAbdominalPain) conditions.push("Gastroenteritis");
  if (hasBreathing) conditions.push("Possible Lower Respiratory Infection");
  if (conditions.length === 0) conditions.push("General Viral Syndrome");

  return {
    possibleConditions: conditions,
    feverTypes: feverTypes.slice(0, 5),
    hasFever,
    suggestions,
    precautions,
    medicines,
    severity,
    seekUrgentCare: hasSevere || severity === "severe",
  };
}
