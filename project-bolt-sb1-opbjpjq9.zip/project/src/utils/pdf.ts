import { jsPDF } from "jspdf";
import { Diagnosis } from "../data/symptoms";

export function generatePDF(
  userName: string,
  userAge: number,
  diagnosis: Diagnosis,
  selectedSymptoms: string[]
): void {
  const pdf = new jsPDF({
    orientation: "portrait",
    unit: "mm",
    format: "a4",
  });

  const pageWidth = pdf.internal.pageSize.getWidth();
  const pageHeight = pdf.internal.pageSize.getHeight();
  let yPosition = 15;
  const lineHeight = 5;
  const margin = 15;
  const contentWidth = pageWidth - 2 * margin;

  const primaryColor = { r: 15, g: 118, b: 255 };
  const textColor = { r: 51, g: 65, b: 85 };
  const lightGray = { r: 209, g: 213, b: 219 };

  pdf.setDrawColor(primaryColor.r, primaryColor.g, primaryColor.b);
  pdf.setLineWidth(0.5);
  pdf.rect(margin, yPosition - 5, contentWidth, 25, "S");

  pdf.setFont("helvetica", "bold");
  pdf.setFontSize(18);
  pdf.setTextColor(primaryColor.r, primaryColor.g, primaryColor.b);
  pdf.text("NOVA MED AI", margin + 5, yPosition + 3);

  pdf.setFont("helvetica", "normal");
  pdf.setFontSize(9);
  pdf.setTextColor(lightGray.r, lightGray.g, lightGray.b);
  pdf.text("Medical Symptom Analysis Report", margin + 5, yPosition + 8);

  yPosition += 30;

  pdf.setFontSize(12);
  pdf.setFont("helvetica", "bold");
  pdf.setTextColor(textColor.r, textColor.g, textColor.b);
  pdf.text("PATIENT INFORMATION", margin, yPosition);

  yPosition += 8;
  pdf.setFontSize(10);
  pdf.setFont("helvetica", "normal");
  pdf.text(`Name: ${userName}`, margin, yPosition);
  yPosition += 6;
  pdf.text(`Age: ${userAge} years`, margin, yPosition);
  yPosition += 6;
  pdf.text(`Report Date: ${new Date().toLocaleDateString()}`, margin, yPosition);

  yPosition += 12;

  pdf.setFont("helvetica", "bold");
  pdf.setFontSize(12);
  pdf.text("SEVERITY ASSESSMENT", margin, yPosition);

  yPosition += 8;
  pdf.setFontSize(10);
  pdf.setFont("helvetica", "normal");
  const severityColor =
    diagnosis.severity === "severe"
      ? { r: 239, g: 68, b: 68 }
      : diagnosis.severity === "moderate"
      ? { r: 217, g: 119, b: 6 }
      : { r: 34, g: 197, b: 94 };

  pdf.setTextColor(severityColor.r, severityColor.g, severityColor.b);
  pdf.setFont("helvetica", "bold");
  pdf.text(`${diagnosis.severity.toUpperCase()}`, margin, yPosition);
  yPosition += 8;

  pdf.setTextColor(textColor.r, textColor.g, textColor.b);
  pdf.setFont("helvetica", "normal");

  if (diagnosis.seekUrgentCare) {
    pdf.setTextColor(239, 68, 68);
    pdf.setFont("helvetica", "bold");
    pdf.text("⚠ URGENT CARE RECOMMENDED", margin, yPosition);
    yPosition += 6;
    pdf.setTextColor(textColor.r, textColor.g, textColor.b);
    pdf.setFont("helvetica", "normal");
  }

  yPosition += 6;

  pdf.setFont("helvetica", "bold");
  pdf.setFontSize(12);
  pdf.text("REPORTED SYMPTOMS", margin, yPosition);

  yPosition += 8;
  pdf.setFontSize(9);
  pdf.setFont("helvetica", "normal");

  selectedSymptoms.forEach((symptom) => {
    if (yPosition > pageHeight - 20) {
      pdf.addPage();
      yPosition = 15;
    }
    pdf.text(`• ${symptom}`, margin + 5, yPosition);
    yPosition += 5;
  });

  yPosition += 5;

  if (diagnosis.feverTypes.length > 0) {
    if (yPosition > pageHeight - 40) {
      pdf.addPage();
      yPosition = 15;
    }

    pdf.setFont("helvetica", "bold");
    pdf.setFontSize(12);
    pdf.text("FEVER TYPE ANALYSIS", margin, yPosition);
    yPosition += 8;

    pdf.setFontSize(9);
    pdf.setFont("helvetica", "normal");

    diagnosis.feverTypes.slice(0, 5).forEach((fever) => {
      if (yPosition > pageHeight - 25) {
        pdf.addPage();
        yPosition = 15;
      }

      pdf.setFont("helvetica", "bold");
      pdf.setTextColor(primaryColor.r, primaryColor.g, primaryColor.b);
      pdf.text(`${fever.name}`, margin, yPosition);
      yPosition += 5;

      pdf.setFont("helvetica", "normal");
      pdf.setTextColor(textColor.r, textColor.g, textColor.b);
      pdf.text(`Probability: ${fever.probability}%`, margin + 5, yPosition);
      yPosition += 5;
    });
  }

  yPosition += 5;

  if (yPosition > pageHeight - 50) {
    pdf.addPage();
    yPosition = 15;
  }

  pdf.setFont("helvetica", "bold");
  pdf.setFontSize(12);
  pdf.text("RECOMMENDATIONS", margin, yPosition);
  yPosition += 8;

  pdf.setFontSize(9);
  pdf.setFont("helvetica", "normal");
  pdf.text("Suggestions:", margin, yPosition);
  yPosition += 5;

  diagnosis.suggestions.slice(0, 3).forEach((suggestion) => {
    if (yPosition > pageHeight - 15) {
      pdf.addPage();
      yPosition = 15;
    }
    const lines = pdf.splitTextToSize(`• ${suggestion}`, contentWidth - 5);
    lines.forEach((line: string) => {
      pdf.text(line, margin + 3, yPosition);
      yPosition += 4;
    });
  });

  yPosition += 3;
  pdf.text("Precautions:", margin, yPosition);
  yPosition += 5;

  diagnosis.precautions.slice(0, 3).forEach((precaution) => {
    if (yPosition > pageHeight - 15) {
      pdf.addPage();
      yPosition = 15;
    }
    const lines = pdf.splitTextToSize(`• ${precaution}`, contentWidth - 5);
    lines.forEach((line: string) => {
      pdf.text(line, margin + 3, yPosition);
      yPosition += 4;
    });
  });

  if (yPosition > pageHeight - 30) {
    pdf.addPage();
    yPosition = 15;
  }

  yPosition += 5;
  pdf.setDrawColor(lightGray.r, lightGray.g, lightGray.b);
  pdf.setLineWidth(0.3);
  pdf.line(margin, yPosition, pageWidth - margin, yPosition);
  yPosition += 8;

  pdf.setFontSize(8);
  pdf.setTextColor(lightGray.r, lightGray.g, lightGray.b);
  pdf.setFont("helvetica", "bold");
  pdf.text("DISCLAIMER", margin, yPosition);
  yPosition += 4;

  pdf.setFont("helvetica", "normal");
  const disclaimerText =
    "This report is generated by Nova Med AI and is for informational purposes only. It is not a substitute for professional medical advice, diagnosis, or treatment. Always consult a qualified healthcare professional for medical concerns. In case of emergency, contact your local emergency services immediately.";

  const disclaimerLines = pdf.splitTextToSize(disclaimerText, contentWidth - 5);
  disclaimerLines.forEach((line: string) => {
    if (yPosition > pageHeight - 10) {
      pdf.addPage();
      yPosition = 15;
    }
    pdf.text(line, margin, yPosition);
    yPosition += 3;
  });

  pdf.save(`NovaAI_Report_${userName}_${new Date().toISOString().split('T')[0]}.pdf`);
}
