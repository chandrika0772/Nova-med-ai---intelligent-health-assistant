import React from "react";
import { useTheme } from "../context/ThemeContext";

interface StepIndicatorProps {
  currentStep: number;
  totalSteps: number;
}

const steps = ["Login", "Symptoms", "Analysis", "More Info", "Results"];

export default function StepIndicator({ currentStep, totalSteps }: StepIndicatorProps) {
  const { isDark } = useTheme();

  return (
    <div className="flex items-center justify-center gap-1 mb-8">
      {steps.map((label, index) => {
        const stepNum = index + 1;
        const isCompleted = stepNum < currentStep;
        const isActive = stepNum === currentStep;
        return (
          <React.Fragment key={stepNum}>
            <div className="flex flex-col items-center">
              <div
                className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-semibold transition-all duration-300 ${
                  isCompleted
                    ? "bg-emerald-500 text-white"
                    : isActive
                    ? isDark
                      ? "bg-sky-600 text-white ring-4 ring-sky-900/50"
                      : "bg-sky-600 text-white ring-4 ring-sky-200"
                    : isDark
                    ? "bg-slate-700 text-slate-400"
                    : "bg-gray-200 text-gray-400"
                }`}
              >
                {isCompleted ? (
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M5 13l4 4L19 7" />
                  </svg>
                ) : (
                  stepNum
                )}
              </div>
              <span
                className={`text-xs mt-1 font-medium hidden sm:block transition-colors ${
                  isActive
                    ? "text-sky-600 dark:text-sky-400"
                    : isCompleted
                    ? "text-emerald-500"
                    : isDark
                    ? "text-slate-500"
                    : "text-gray-400"
                }`}
              >
                {label}
              </span>
            </div>
            {index < steps.length - 1 && (
              <div
                className={`flex-1 h-0.5 mx-1 mb-4 sm:mb-0 transition-all duration-300 ${
                  isCompleted
                    ? "bg-emerald-400"
                    : isDark
                    ? "bg-slate-700"
                    : "bg-gray-200"
                }`}
                style={{ minWidth: "24px", maxWidth: "60px" }}
              />
            )}
          </React.Fragment>
        );
      })}
    </div>
  );
}
