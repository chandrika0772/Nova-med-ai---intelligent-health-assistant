import { AlertTriangle, Phone } from "lucide-react";
import { useTheme } from "../context/ThemeContext";

export default function EmergencyBanner() {
  const { isDark } = useTheme();

  const emergencyNumbers = [
    { country: "India", number: "102 / 108", label: "Ambulance" },
    { country: "USA", number: "911", label: "Emergency" },
    { country: "UK", number: "999", label: "Emergency" },
    { country: "Australia", number: "000", label: "Emergency" },
  ];

  return (
    <div className={`${isDark ? "bg-red-900/20 border-red-700" : "bg-red-50 border-red-200"} border rounded-2xl p-4 backdrop-blur-glass`}>
      <div className="flex items-start gap-3">
        <AlertTriangle className={`w-5 h-5 ${isDark ? "text-red-400" : "text-red-500"} flex-shrink-0 mt-0.5`} />
        <div className="flex-1">
          <p className={`${isDark ? "text-red-300" : "text-red-800"} font-semibold text-sm mb-3`}>
            Emergency? Contact Immediately
          </p>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {emergencyNumbers.map((item) => (
              <div key={item.country} className={`${isDark ? "bg-red-900/30 border-red-700" : "bg-white border-red-100"} border rounded-lg p-2`}>
                <p className={`text-xs ${isDark ? "text-red-200" : "text-red-700"} font-semibold`}>{item.country}</p>
                <p className={`flex items-center gap-1 text-sm font-bold ${isDark ? "text-red-400" : "text-red-600"} mt-1`}>
                  <Phone className="w-3 h-3" />
                  {item.number}
                </p>
                <p className={`text-xs ${isDark ? "text-red-300" : "text-red-600"}`}>{item.label}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
