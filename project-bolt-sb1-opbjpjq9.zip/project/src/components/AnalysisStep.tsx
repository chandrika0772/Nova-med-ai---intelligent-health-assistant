import { Loader2, Brain, ArrowRight } from "lucide-react";
import { useEffect, useState } from "react";
import { useTheme } from "../context/ThemeContext";

interface AnalysisStepProps {
  onContinue: () => void;
}

const ANALYSIS_STEPS = [
  "Reading your symptom profile...",
  "Cross-referencing medical database...",
  "Analyzing fever patterns...",
  "Calculating condition probabilities...",
  "Preparing your health report...",
];

export default function AnalysisStep({ onContinue }: AnalysisStepProps) {
  const { isDark } = useTheme();
  const [currentStep, setCurrentStep] = useState(0);
  const [done, setDone] = useState(false);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentStep((prev) => {
        if (prev >= ANALYSIS_STEPS.length - 1) {
          clearInterval(interval);
          setTimeout(() => setDone(true), 500);
          return prev;
        }
        return prev + 1;
      });
    }, 600);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="w-full max-w-md mx-auto text-center">
      <div className={`${isDark ? "bg-slate-800/80 border-slate-700" : "bg-white"} rounded-2xl shadow-xl shadow-slate-200 dark:shadow-slate-900/30 border ${isDark ? "border-slate-700" : "border-slate-100"} p-10 backdrop-blur-glass`}>
        <div className="flex justify-center mb-6">
          <div className={`w-20 h-20 bg-gradient-to-br from-sky-500 to-cyan-600 rounded-2xl flex items-center justify-center shadow-lg ${isDark ? "shadow-sky-900/50" : "shadow-sky-200"} relative`}>
            <Brain className="w-10 h-10 text-white" />
            {!done && (
              <div className="absolute -top-1 -right-1 w-5 h-5 bg-amber-400 rounded-full flex items-center justify-center">
                <Loader2 className="w-3 h-3 text-white animate-spin" />
              </div>
            )}
          </div>
        </div>

        <h2 className={`text-xl font-bold ${isDark ? "text-white" : "text-slate-800"} mb-2`}>
          {done ? "Analysis Complete!" : "Analyzing Your Symptoms"}
        </h2>
        <p className={`${isDark ? "text-slate-400" : "text-slate-400"} text-sm mb-8`}>
          {done
            ? "Nova Med AI has finished analyzing your symptoms. Before we show your full report, we have one more question."
            : "Nova Med AI is processing your symptom data using our medical knowledge base."}
        </p>

        <div className="space-y-3 mb-8 text-left">
          {ANALYSIS_STEPS.map((step, index) => (
            <div
              key={index}
              className={`flex items-center gap-3 text-sm transition-all duration-300 ${
                index < currentStep
                  ? isDark
                    ? "text-emerald-400"
                    : "text-emerald-600"
                  : index === currentStep
                  ? isDark
                    ? "text-sky-400"
                    : "text-sky-600"
                  : isDark
                  ? "text-slate-500"
                  : "text-slate-300"
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0 transition-all ${
                  index < currentStep
                    ? "bg-emerald-500"
                    : index === currentStep
                    ? "bg-sky-500"
                    : isDark
                    ? "bg-slate-700"
                    : "bg-slate-200"
                }`}
              >
                {index < currentStep ? (
                  <svg className="w-3 h-3 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M5 13l4 4L19 7" />
                  </svg>
                ) : index === currentStep && !done ? (
                  <Loader2 className="w-2.5 h-2.5 text-white animate-spin" />
                ) : (
                  <div className={`w-1.5 h-1.5 rounded-full ${isDark ? "bg-slate-600" : "bg-slate-400"}`} />
                )}
              </div>
              <span className={index === currentStep && !done ? "font-medium" : ""}>{step}</span>
            </div>
          ))}
        </div>

        {done && (
          <button
            onClick={onContinue}
            className="w-full bg-gradient-to-r from-sky-500 to-cyan-600 text-white py-3 rounded-xl font-semibold text-sm hover:from-sky-600 hover:to-cyan-700 transition-all duration-200 flex items-center justify-center gap-2 shadow-md shadow-sky-200 dark:shadow-sky-900/50 hover:shadow-lg hover:-translate-y-0.5"
          >
            Continue
            <ArrowRight className="w-4 h-4" />
          </button>
        )}
      </div>
    </div>
  );
}
