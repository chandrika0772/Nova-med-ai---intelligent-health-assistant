import { useState } from "react";
import { MessageCircle, ArrowRight, SkipForward } from "lucide-react";
import { useTheme } from "../context/ThemeContext";

interface AdditionalSymptomsStepProps {
  onSubmit: (hasMore: boolean, text: string) => void;
}

export default function AdditionalSymptomsStep({ onSubmit }: AdditionalSymptomsStepProps) {
  const { isDark } = useTheme();
  const [hasMore, setHasMore] = useState<boolean | null>(null);
  const [text, setText] = useState("");

  function handleYes() {
    setHasMore(true);
  }

  function handleNo() {
    onSubmit(false, "");
  }

  function handleSubmit() {
    onSubmit(true, text);
  }

  return (
    <div className="w-full max-w-md mx-auto">
      <div className={`${isDark ? "bg-slate-800/80 border-slate-700" : "bg-white"} rounded-2xl shadow-xl shadow-slate-200 dark:shadow-slate-900/30 border ${isDark ? "border-slate-700" : "border-slate-100"} p-8 backdrop-blur-glass`}>
        <div className="flex justify-center mb-5">
          <div className={`w-14 h-14 ${isDark ? "bg-amber-900/30" : "bg-amber-100"} rounded-2xl flex items-center justify-center shadow-md ${isDark ? "shadow-amber-900/50" : "shadow-amber-100"}`}>
            <MessageCircle className={`w-7 h-7 ${isDark ? "text-amber-400" : "text-amber-500"}`} />
          </div>
        </div>

        <h2 className={`text-xl font-bold ${isDark ? "text-white" : "text-slate-800"} text-center mb-2`}>Anything else to add?</h2>
        <p className={`${isDark ? "text-slate-400" : "text-slate-400"} text-sm text-center mb-8`}>
          Other than the symptoms you've already mentioned, are there any additional symptoms, duration, or medical history you'd like to share?
        </p>

        {hasMore === null ? (
          <div className="grid grid-cols-2 gap-3">
            <button
              onClick={handleYes}
              className={`py-3.5 rounded-xl border-2 font-semibold text-sm transition-all duration-200 hover:-translate-y-0.5 ${
                isDark
                  ? "border-sky-600 bg-sky-900/30 text-sky-300 hover:bg-sky-900/50"
                  : "border-sky-300 bg-sky-50 text-sky-700 hover:bg-sky-100 hover:border-sky-400"
              }`}
            >
              Yes, I have more
            </button>
            <button
              onClick={handleNo}
              className={`py-3.5 rounded-xl border-2 font-semibold text-sm transition-all duration-200 hover:-translate-y-0.5 ${
                isDark
                  ? "border-slate-600 bg-slate-700/30 text-slate-300 hover:bg-slate-700/50"
                  : "border-slate-200 bg-slate-50 text-slate-600 hover:bg-slate-100 hover:border-slate-300"
              }`}
            >
              No, that's all
            </button>
          </div>
        ) : (
          <div>
            <label className={`block text-sm font-medium ${isDark ? "text-slate-300" : "text-slate-600"} mb-1.5`}>
              Please describe your additional symptoms or details
            </label>
            <textarea
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder="e.g., I've been sick for 5 days, I have diabetes, I recently travelled, I've been vomiting since morning..."
              rows={4}
              className={`w-full px-4 py-3 rounded-xl border text-sm focus:outline-none focus:ring-2 transition-all resize-none mb-2 ${
                isDark
                  ? "bg-slate-700 text-white placeholder-slate-500 border-slate-600 focus:ring-sky-400/30 focus:border-sky-500"
                  : "bg-white text-slate-700 placeholder-slate-300 border-slate-200 focus:ring-sky-200 focus:border-sky-400"
              }`}
            />
            <p className={`text-slate-400 text-xs mb-5 flex items-center gap-1`}>
              <span className={`w-3.5 h-3.5 inline-flex items-center justify-center rounded-full ${isDark ? "bg-amber-900/50 text-amber-500" : "bg-amber-100 text-amber-600"} font-bold text-[9px] flex-shrink-0`}>!</span>
              Nova Med AI can make mistakes. Please consult your doctor for proper medical advice.
            </p>

            <div className="flex gap-3">
              <button
                onClick={() => setHasMore(null)}
                className={`flex items-center gap-1.5 text-sm transition-colors ${
                  isDark
                    ? "text-slate-400 hover:text-slate-300"
                    : "text-slate-400 hover:text-slate-600"
                }`}
              >
                <SkipForward className="w-3.5 h-3.5" />
                Go back
              </button>
              <button
                onClick={handleSubmit}
                className="flex-1 bg-gradient-to-r from-sky-500 to-cyan-600 text-white py-3 rounded-xl font-semibold text-sm hover:from-sky-600 hover:to-cyan-700 transition-all duration-200 flex items-center justify-center gap-2 shadow-md shadow-sky-200 dark:shadow-sky-900/50 hover:shadow-lg hover:-translate-y-0.5"
              >
                View My Report
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
