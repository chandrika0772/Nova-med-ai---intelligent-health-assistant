import { Stethoscope, Moon, Sun, Menu, X, Info, Zap, BookOpen } from "lucide-react";
import { useTheme } from "../context/ThemeContext";
import { useState } from "react";

interface HeaderProps {
  onNavigate: (page: "home" | "about" | "tech" | "project") => void;
  currentPage: "home" | "about" | "tech" | "project";
}

export default function Header({ onNavigate, currentPage }: HeaderProps) {
  const { isDark, toggleTheme } = useTheme();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const menuItems = [
    { id: "home", label: "Home", icon: Stethoscope },
    { id: "about", label: "About", icon: Info },
    { id: "tech", label: "Tech Stack", icon: Zap },
    { id: "project", label: "Project", icon: BookOpen },
  ];

  return (
    <header className={`${isDark ? "bg-slate-800/80 border-slate-700" : "bg-white/80"} border-b backdrop-blur-md sticky top-0 z-40`}>
      <div className="max-w-7xl mx-auto px-4 py-3.5">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <button
            onClick={() => { onNavigate("home"); setMobileMenuOpen(false); }}
            className="flex items-center gap-2.5 hover:opacity-80 transition-opacity"
          >
            <div className={`w-8 h-8 bg-gradient-to-br from-sky-500 to-cyan-600 rounded-lg flex items-center justify-center`}>
              <Stethoscope className="w-4 h-4 text-white" />
            </div>
            <div>
              <span className={`font-bold ${isDark ? "text-white" : "text-slate-800"} text-sm`}>Nova Med AI</span>
              <p className={`${isDark ? "text-slate-500" : "text-slate-400"} text-[10px] leading-none`}>Healthcare AI</p>
            </div>
          </button>

          {/* Desktop Menu */}
          <div className="hidden md:flex items-center gap-1">
            {menuItems.map((item) => (
              <button
                key={item.id}
                onClick={() => onNavigate(item.id as any)}
                className={`px-3 py-2 rounded-lg text-sm font-medium transition-colors flex items-center gap-1.5 ${
                  currentPage === item.id
                    ? isDark
                      ? "bg-sky-900/50 text-sky-300"
                      : "bg-sky-100 text-sky-700"
                    : isDark
                    ? "text-slate-400 hover:text-slate-300 hover:bg-slate-700/50"
                    : "text-slate-600 hover:text-slate-800 hover:bg-slate-100"
                }`}
              >
                <item.icon className="w-4 h-4" />
                {item.label}
              </button>
            ))}
          </div>

          {/* Right Actions */}
          <div className="flex items-center gap-2">
            <button
              onClick={toggleTheme}
              className={`p-2 rounded-lg transition-colors ${
                isDark
                  ? "bg-slate-700 hover:bg-slate-600 text-yellow-400"
                  : "bg-slate-100 hover:bg-slate-200 text-slate-600"
              }`}
              title={isDark ? "Switch to light mode" : "Switch to dark mode"}
            >
              {isDark ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </button>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className={`md:hidden p-2 rounded-lg transition-colors ${
                isDark
                  ? "bg-slate-700 hover:bg-slate-600 text-slate-300"
                  : "bg-slate-100 hover:bg-slate-200 text-slate-600"
              }`}
            >
              {mobileMenuOpen ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className={`md:hidden mt-4 pb-4 space-y-2 border-t ${isDark ? "border-slate-700" : "border-slate-100"} pt-4`}>
            {menuItems.map((item) => (
              <button
                key={item.id}
                onClick={() => { onNavigate(item.id as any); setMobileMenuOpen(false); }}
                className={`w-full text-left px-3 py-2 rounded-lg text-sm font-medium transition-colors flex items-center gap-2 ${
                  currentPage === item.id
                    ? isDark
                      ? "bg-sky-900/50 text-sky-300"
                      : "bg-sky-100 text-sky-700"
                    : isDark
                    ? "text-slate-400 hover:text-slate-300 hover:bg-slate-700/50"
                    : "text-slate-600 hover:text-slate-800 hover:bg-slate-100"
                }`}
              >
                <item.icon className="w-4 h-4" />
                {item.label}
              </button>
            ))}
          </div>
        )}
      </div>
    </header>
  );
}
