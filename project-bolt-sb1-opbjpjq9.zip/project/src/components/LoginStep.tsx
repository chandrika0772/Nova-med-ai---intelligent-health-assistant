import { useState } from "react";
import { User, Calendar, ArrowRight, Shield, Stethoscope } from "lucide-react";
import { useTheme } from "../context/ThemeContext";

interface LoginStepProps {
  onSubmit: (name: string, age: number) => void;
}

export default function LoginStep({ onSubmit }: LoginStepProps) {
  const { isDark } = useTheme();
  const [name, setName] = useState("");
  const [age, setAge] = useState("");
  const [errors, setErrors] = useState<{ name?: string; age?: string }>({});

  function validate() {
    const newErrors: { name?: string; age?: string } = {};
    if (!name.trim()) newErrors.name = "Please enter your name.";
    else if (name.trim().length < 2) newErrors.name = "Name must be at least 2 characters.";
    if (!age) newErrors.age = "Please enter your age.";
    else if (parseInt(age) < 1 || parseInt(age) > 120) newErrors.age = "Please enter a valid age (1-120).";
    return newErrors;
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const errs = validate();
    if (Object.keys(errs).length > 0) {
      setErrors(errs);
      return;
    }
    onSubmit(name.trim(), parseInt(age));
  }

  return (
    <div className="w-full max-w-md mx-auto">
      <div className="text-center mb-8">
        <div className="flex justify-center mb-4">
          <div className="w-20 h-20 bg-gradient-to-br from-sky-500 to-cyan-600 rounded-2xl flex items-center justify-center shadow-lg shadow-sky-200 dark:shadow-sky-900/50">
            <Stethoscope className="w-10 h-10 text-white" />
          </div>
        </div>
        <h1 className={`text-3xl font-bold tracking-tight ${isDark ? "text-white" : "text-slate-800"}`}>Nova Med AI</h1>
        <p className={`${isDark ? "text-slate-400" : "text-slate-500"} mt-2 text-sm`}>Your intelligent medical symptom assistant</p>
      </div>

      <div className={`${isDark ? "bg-slate-800/80 border-slate-700" : "bg-white"} rounded-2xl shadow-xl shadow-slate-200 dark:shadow-slate-900/30 border ${isDark ? "border-slate-700" : "border-slate-100"} p-8 backdrop-blur-glass`}>
        <h2 className={`text-xl font-semibold ${isDark ? "text-white" : "text-slate-700"} mb-1`}>Welcome! Let's get started</h2>
        <p className={`${isDark ? "text-slate-400" : "text-slate-400"} text-sm mb-6`}>Please provide your basic information to continue.</p>

        <form onSubmit={handleSubmit} className="space-y-5">
          <div>
            <label className={`block text-sm font-medium ${isDark ? "text-slate-300" : "text-slate-600"} mb-1.5`}>Full Name</label>
            <div className="relative">
              <User className={`absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 ${isDark ? "text-slate-500" : "text-slate-400"}`} />
              <input
                type="text"
                value={name}
                onChange={(e) => { setName(e.target.value); setErrors(prev => ({ ...prev, name: undefined })); }}
                placeholder="Enter your full name"
                className={`w-full pl-10 pr-4 py-3 rounded-xl border text-sm focus:outline-none focus:ring-2 transition-all ${
                  isDark
                    ? `bg-slate-700 text-white placeholder-slate-500 ${
                        errors.name
                          ? "border-red-500 focus:ring-red-400/30"
                          : "border-slate-600 focus:ring-sky-400/30 focus:border-sky-500"
                      }`
                    : `bg-white text-slate-700 placeholder-slate-300 ${
                        errors.name
                          ? "border-red-300 focus:ring-red-200"
                          : "border-slate-200 focus:ring-sky-200 focus:border-sky-400"
                      }`
                }`}
              />
            </div>
            {errors.name && <p className={`text-red-500 text-xs mt-1`}>{errors.name}</p>}
          </div>

          <div>
            <label className={`block text-sm font-medium ${isDark ? "text-slate-300" : "text-slate-600"} mb-1.5`}>Age</label>
            <div className="relative">
              <Calendar className={`absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 ${isDark ? "text-slate-500" : "text-slate-400"}`} />
              <input
                type="number"
                value={age}
                onChange={(e) => { setAge(e.target.value); setErrors(prev => ({ ...prev, age: undefined })); }}
                placeholder="Enter your age"
                min={1}
                max={120}
                className={`w-full pl-10 pr-4 py-3 rounded-xl border text-sm focus:outline-none focus:ring-2 transition-all ${
                  isDark
                    ? `bg-slate-700 text-white placeholder-slate-500 ${
                        errors.age
                          ? "border-red-500 focus:ring-red-400/30"
                          : "border-slate-600 focus:ring-sky-400/30 focus:border-sky-500"
                      }`
                    : `bg-white text-slate-700 placeholder-slate-300 ${
                        errors.age
                          ? "border-red-300 focus:ring-red-200"
                          : "border-slate-200 focus:ring-sky-200 focus:border-sky-400"
                      }`
                }`}
              />
            </div>
            {errors.age && <p className={`text-red-500 text-xs mt-1`}>{errors.age}</p>}
          </div>

          <button
            type="submit"
            className="w-full bg-gradient-to-r from-sky-500 to-cyan-600 text-white py-3 rounded-xl font-semibold text-sm hover:from-sky-600 hover:to-cyan-700 transition-all duration-200 flex items-center justify-center gap-2 shadow-md shadow-sky-200 dark:shadow-sky-900/50 hover:shadow-lg hover:-translate-y-0.5 active:translate-y-0"
          >
            Begin Symptom Check
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>

        <div className={`mt-6 pt-5 border-t ${isDark ? "border-slate-700" : "border-slate-100"} flex items-center gap-2 text-xs ${isDark ? "text-slate-400" : "text-slate-400"}`}>
          <Shield className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0" />
          <span>Your information is private and used only for symptom analysis.</span>
        </div>
      </div>
    </div>
  );
}
