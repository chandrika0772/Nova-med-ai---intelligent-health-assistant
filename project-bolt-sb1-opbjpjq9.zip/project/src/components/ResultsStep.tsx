import { Diagnosis } from "../data/symptoms";
import {
  Thermometer, Shield, Pill, AlertTriangle, CheckCircle,
  RotateCcw, ChevronDown, ChevronUp, Activity
} from "lucide-react";
import { useState } from "react";

interface ResultsStepProps {
  diagnosis: Diagnosis;
  userName: string;
  userAge: number;
  onRestart: () => void;
}

function ProbabilityBar({ value }: { value: number }) {
  const color = value >= 70 ? "bg-red-500" : value >= 50 ? "bg-amber-500" : "bg-sky-500";
  return (
    <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
      <div
        className={`h-2 rounded-full transition-all duration-700 ${color}`}
        style={{ width: `${value}%` }}
      />
    </div>
  );
}

function SeverityBadge({ severity }: { severity: "mild" | "moderate" | "severe" }) {
  const styles = {
    mild: "bg-emerald-100 text-emerald-700 border-emerald-200",
    moderate: "bg-amber-100 text-amber-700 border-amber-200",
    severe: "bg-red-100 text-red-700 border-red-200",
  };
  return (
    <span className={`text-xs font-semibold px-2.5 py-1 rounded-full border capitalize ${styles[severity]}`}>
      {severity} severity
    </span>
  );
}

export default function ResultsStep({ diagnosis, userName, userAge, onRestart }: ResultsStepProps) {
  const [expandedFever, setExpandedFever] = useState<string | null>(null);

  return (
    <div className="w-full max-w-2xl mx-auto space-y-5 pb-8">
      {diagnosis.seekUrgentCare && (
        <div className="bg-red-50 border border-red-200 rounded-2xl p-4 flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
          <div>
            <p className="text-red-700 font-semibold text-sm">Urgent Medical Attention Recommended</p>
            <p className="text-red-600 text-xs mt-0.5">Your symptoms suggest a serious condition. Please visit a hospital or doctor immediately.</p>
          </div>
        </div>
      )}

      {/* Header */}
      <div className="bg-gradient-to-r from-sky-500 to-cyan-600 rounded-2xl p-6 text-white shadow-lg shadow-sky-200">
        <div className="flex items-start justify-between gap-4">
          <div>
            <p className="text-sky-100 text-sm font-medium mb-1">Health Report for</p>
            <h2 className="text-2xl font-bold">{userName}, {userAge} yrs</h2>
            <p className="text-sky-100 text-sm mt-2">
              Based on your symptoms, Nova Med AI has prepared a comprehensive analysis.
            </p>
          </div>
          <div className="flex flex-col items-end gap-2">
            <SeverityBadge severity={diagnosis.severity} />
            <div className="bg-white/20 rounded-xl px-3 py-1.5 text-xs font-medium text-white">
              {diagnosis.possibleConditions[0]}
            </div>
          </div>
        </div>
      </div>

      {/* Fever Detection */}
      {diagnosis.hasFever && diagnosis.feverTypes.length > 0 && (
        <div className="bg-white rounded-2xl shadow-xl shadow-slate-200 border border-slate-100 p-6">
          <div className="flex items-center gap-2.5 mb-4">
            <div className="w-8 h-8 bg-red-100 rounded-lg flex items-center justify-center">
              <Thermometer className="w-4 h-4 text-red-500" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-800">Fever Type Detection</h3>
              <p className="text-slate-400 text-xs">Probability analysis based on your symptoms</p>
            </div>
          </div>

          <div className="space-y-3">
            {diagnosis.feverTypes.map((fever) => (
              <div key={fever.name} className="border border-slate-100 rounded-xl overflow-hidden">
                <button
                  onClick={() => setExpandedFever(expandedFever === fever.name ? null : fever.name)}
                  className="w-full p-4 flex items-center justify-between hover:bg-slate-50 transition-colors"
                >
                  <div className="flex items-center gap-3 flex-1 min-w-0">
                    <div className={`w-2.5 h-2.5 rounded-full flex-shrink-0 ${
                      fever.probability >= 70 ? "bg-red-500" : fever.probability >= 50 ? "bg-amber-500" : "bg-sky-500"
                    }`} />
                    <span className="text-sm font-semibold text-slate-700 text-left">{fever.name}</span>
                  </div>
                  <div className="flex items-center gap-3 flex-shrink-0 ml-3">
                    <div className="text-right">
                      <span className={`text-base font-bold ${
                        fever.probability >= 70 ? "text-red-600" : fever.probability >= 50 ? "text-amber-600" : "text-sky-600"
                      }`}>
                        {fever.probability}%
                      </span>
                      <div className="w-24 mt-1">
                        <ProbabilityBar value={fever.probability} />
                      </div>
                    </div>
                    {expandedFever === fever.name ? (
                      <ChevronUp className="w-4 h-4 text-slate-400" />
                    ) : (
                      <ChevronDown className="w-4 h-4 text-slate-400" />
                    )}
                  </div>
                </button>
                {expandedFever === fever.name && (
                  <div className="px-4 pb-4 bg-slate-50 border-t border-slate-100">
                    <p className="text-slate-500 text-xs mt-3 mb-2">{fever.description}</p>
                    <div className="flex flex-wrap gap-1.5">
                      {fever.symptoms.map((s) => (
                        <span key={s} className="text-xs bg-white border border-slate-200 text-slate-600 px-2.5 py-0.5 rounded-full">
                          {s}
                        </span>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>

          <div className="mt-4 bg-amber-50 border border-amber-200 rounded-xl p-3 text-xs text-amber-700 flex items-start gap-2">
            <AlertTriangle className="w-3.5 h-3.5 flex-shrink-0 mt-0.5 text-amber-500" />
            <span>These are estimated probabilities. A blood test and doctor's examination are required for accurate diagnosis.</span>
          </div>
        </div>
      )}

      {/* Suggestions */}
      <div className="bg-white rounded-2xl shadow-xl shadow-slate-200 border border-slate-100 p-6">
        <div className="flex items-center gap-2.5 mb-4">
          <div className="w-8 h-8 bg-sky-100 rounded-lg flex items-center justify-center">
            <Activity className="w-4 h-4 text-sky-500" />
          </div>
          <h3 className="text-base font-bold text-slate-800">Suggestions for Recovery</h3>
        </div>
        <ul className="space-y-2.5">
          {diagnosis.suggestions.map((s, i) => (
            <li key={i} className="flex items-start gap-2.5 text-sm text-slate-600">
              <CheckCircle className="w-4 h-4 text-sky-400 flex-shrink-0 mt-0.5" />
              <span>{s}</span>
            </li>
          ))}
        </ul>
      </div>

      {/* Precautions */}
      <div className="bg-white rounded-2xl shadow-xl shadow-slate-200 border border-slate-100 p-6">
        <div className="flex items-center gap-2.5 mb-4">
          <div className="w-8 h-8 bg-emerald-100 rounded-lg flex items-center justify-center">
            <Shield className="w-4 h-4 text-emerald-500" />
          </div>
          <h3 className="text-base font-bold text-slate-800">Precautions to Follow</h3>
        </div>
        <ul className="space-y-2.5">
          {diagnosis.precautions.map((p, i) => (
            <li key={i} className="flex items-start gap-2.5 text-sm text-slate-600">
              <div className="w-4 h-4 rounded-full bg-emerald-100 flex items-center justify-center flex-shrink-0 mt-0.5">
                <div className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
              </div>
              <span>{p}</span>
            </li>
          ))}
        </ul>
      </div>

      {/* Medicines */}
      <div className="bg-white rounded-2xl shadow-xl shadow-slate-200 border border-slate-100 p-6">
        <div className="flex items-center gap-2.5 mb-4">
          <div className="w-8 h-8 bg-violet-100 rounded-lg flex items-center justify-center">
            <Pill className="w-4 h-4 text-violet-500" />
          </div>
          <div>
            <h3 className="text-base font-bold text-slate-800">Medicine Suggestions</h3>
            <p className="text-slate-400 text-xs">Always consult a doctor before taking any medication</p>
          </div>
        </div>
        <ul className="space-y-2.5">
          {diagnosis.medicines.map((m, i) => (
            <li key={i} className={`flex items-start gap-2.5 text-sm ${m.startsWith("IMPORTANT") ? "text-red-600 font-medium" : "text-slate-600"}`}>
              <Pill className={`w-4 h-4 flex-shrink-0 mt-0.5 ${m.startsWith("IMPORTANT") ? "text-red-400" : "text-violet-400"}`} />
              <span>{m}</span>
            </li>
          ))}
        </ul>
      </div>

      {/* Disclaimer */}
      <div className="bg-amber-50 border border-amber-200 rounded-2xl p-5">
        <div className="flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-amber-500 flex-shrink-0 mt-0.5" />
          <div>
            <p className="text-amber-800 font-semibold text-sm mb-1">Medical Disclaimer</p>
            <p className="text-amber-700 text-xs leading-relaxed">
              Nova Med AI can make mistakes and is not a substitute for professional medical advice.
              This report is for informational purposes only. Please consult a qualified doctor or
              healthcare professional for proper diagnosis and treatment. In case of emergency, call
              your local emergency services immediately.
            </p>
          </div>
        </div>
      </div>

      {/* Restart */}
      <button
        onClick={onRestart}
        className="w-full flex items-center justify-center gap-2 py-3.5 rounded-xl border-2 border-slate-200 text-slate-500 font-medium text-sm hover:border-sky-300 hover:text-sky-600 hover:bg-sky-50 transition-all duration-200"
      >
        <RotateCcw className="w-4 h-4" />
        Start a New Symptom Check
      </button>
    </div>
  );
}
