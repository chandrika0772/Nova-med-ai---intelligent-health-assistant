import { useState } from "react";
import {
  Thermometer, Brain, Wind, Mic, Droplets, Activity, Battery,
  AlertCircle, Waves, Circle, Snowflake, Droplet, Zap, Heart,
  Eye, RefreshCw, Coffee, ArrowRight, CheckCircle2
} from "lucide-react";
import { SYMPTOMS } from "../data/symptoms";
import { useTheme } from "../context/ThemeContext";

const ICON_MAP: Record<string, React.ComponentType<{ className?: string }>> = {
  Thermometer, Brain, Wind, Mic, Droplets, Activity, Battery,
  AlertCircle, Waves, Circle, Snowflake, Droplet, Zap, Heart,
  Eye, RefreshCw, Coffee,
};

interface SymptomsStepProps {
  userName: string;
  userAge: number;
  onSubmit: (selectedIds: string[], additionalText: string) => void;
}

export default function SymptomsStep({ userName, userAge, onSubmit }: SymptomsStepProps) {
  const { isDark } = useTheme();
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [additionalText, setAdditionalText] = useState("");
  const [error, setError] = useState("");

  function toggleSymptom(id: string) {
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
    setError("");
  }

  function handleSubmit() {
    if (selected.size === 0 && additionalText.trim().length === 0) {
      setError("Please select at least one symptom or describe your condition.");
      return;
    }
    onSubmit(Array.from(selected), additionalText);
  }

  return (
    <div className="w-full max-w-2xl mx-auto">
      <div className={`bg-gradient-to-r from-sky-500 to-cyan-600 rounded-2xl p-6 mb-6 text-white shadow-lg shadow-sky-200 dark:shadow-sky-900/50`}>
        <div className="flex items-start gap-4">
          <div className={`w-12 h-12 ${isDark ? "bg-white/20" : "bg-white/20"} rounded-xl flex items-center justify-center flex-shrink-0`}>
            <span className="text-2xl">👋</span>
          </div>
          <div>
            <h2 className="text-xl font-bold">Welcome, {userName}!</h2>
            <p className={`${isDark ? "text-sky-100" : "text-sky-100"} text-sm mt-1`}>
              I'm Nova Med AI, your intelligent medical assistant. I'm here to help analyze your
              symptoms and provide guidance. You're {userAge} years old — let me understand how you're feeling today.
            </p>
          </div>
        </div>
      </div>

      <div className={`${isDark ? "bg-slate-800/80 border-slate-700" : "bg-white"} rounded-2xl shadow-xl shadow-slate-200 dark:shadow-slate-900/30 border ${isDark ? "border-slate-700" : "border-slate-100"} p-6 backdrop-blur-glass`}>
        <h3 className={`text-lg font-semibold ${isDark ? "text-white" : "text-slate-700"} mb-1`}>What symptoms are you experiencing?</h3>
        <p className={`${isDark ? "text-slate-400" : "text-slate-400"} text-sm mb-5`}>Select all that apply. You can also describe additional symptoms below.</p>

        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 mb-6">
          {SYMPTOMS.map((symptom) => {
            const Icon = ICON_MAP[symptom.icon] || Activity;
            const isSelected = selected.has(symptom.id);
            return (
              <button
                key={symptom.id}
                onClick={() => toggleSymptom(symptom.id)}
                className={`flex items-center gap-2.5 p-3 rounded-xl border text-left text-sm font-medium transition-all duration-200 group ${
                  isSelected
                    ? isDark
                      ? "border-sky-500 bg-sky-900/30 text-sky-300"
                      : "border-sky-400 bg-sky-50 text-sky-700"
                    : isDark
                    ? "border-slate-600 text-slate-400 hover:border-sky-500 hover:bg-slate-700/30 hover:text-sky-400"
                    : "border-slate-200 text-slate-600 hover:border-sky-300 hover:bg-sky-50/50 hover:text-sky-600"
                }`}
              >
                <div
                  className={`w-7 h-7 rounded-lg flex items-center justify-center flex-shrink-0 transition-colors ${
                    isSelected
                      ? "bg-sky-500 text-white"
                      : isDark
                      ? "bg-slate-700 text-slate-500 group-hover:bg-sky-900/50 group-hover:text-sky-400"
                      : "bg-slate-100 text-slate-400 group-hover:bg-sky-100 group-hover:text-sky-500"
                  }`}
                >
                  {isSelected ? <CheckCircle2 className="w-4 h-4" /> : <Icon className="w-3.5 h-3.5" />}
                </div>
                <span className="leading-tight">{symptom.label}</span>
              </button>
            );
          })}
        </div>

        <div className="mb-2">
          <label className={`block text-sm font-medium ${isDark ? "text-slate-300" : "text-slate-600"} mb-1.5`}>
            Describe any other symptoms or details
          </label>
          <textarea
            value={additionalText}
            onChange={(e) => { setAdditionalText(e.target.value); setError(""); }}
            placeholder="e.g., I've had a fever for 3 days, feeling very weak, noticed some redness in eyes..."
            rows={3}
            className={`w-full px-4 py-3 rounded-xl border text-sm focus:outline-none focus:ring-2 transition-all resize-none ${
              isDark
                ? "bg-slate-700 text-white placeholder-slate-500 border-slate-600 focus:ring-sky-400/30 focus:border-sky-500"
                : "bg-white text-slate-700 placeholder-slate-300 border-slate-200 focus:ring-sky-200 focus:border-sky-400"
            }`}
          />
          <p className={`text-slate-400 text-xs mt-1.5 flex items-center gap-1`}>
            <span className={`w-3.5 h-3.5 inline-flex items-center justify-center rounded-full ${isDark ? "bg-amber-900/50 text-amber-500" : "bg-amber-100 text-amber-600"} font-bold text-[9px] flex-shrink-0`}>!</span>
            Nova Med AI can make mistakes. Please consult your doctor for proper medical advice.
          </p>
        </div>

        {error && <p className={`text-red-500 text-sm mb-3`}>{error}</p>}

        {selected.size > 0 && (
          <div className="mb-4 flex flex-wrap gap-1.5">
            {Array.from(selected).map(id => {
              const s = SYMPTOMS.find(sym => sym.id === id);
              return s ? (
                <span key={id} className={`text-xs px-2.5 py-1 rounded-full font-medium ${
                  isDark
                    ? "bg-sky-900/30 text-sky-300"
                    : "bg-sky-100 text-sky-700"
                }`}>
                  {s.label}
                </span>
              ) : null;
            })}
          </div>
        )}

        <button
          onClick={handleSubmit}
          className="w-full bg-gradient-to-r from-sky-500 to-cyan-600 text-white py-3 rounded-xl font-semibold text-sm hover:from-sky-600 hover:to-cyan-700 transition-all duration-200 flex items-center justify-center gap-2 shadow-md shadow-sky-200 dark:shadow-sky-900/50 hover:shadow-lg hover:-translate-y-0.5 active:translate-y-0"
        >
          Analyze My Symptoms
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}
