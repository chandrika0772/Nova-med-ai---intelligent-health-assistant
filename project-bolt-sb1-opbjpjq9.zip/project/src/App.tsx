import { useState } from "react";
import { ThemeProvider, useTheme } from "./context/ThemeContext";
import Header from "./components/Header";
import LoginStep from "./components/LoginStep";
import SymptomsStep from "./components/SymptomsStep";
import AnalysisStep from "./components/AnalysisStep";
import AdditionalSymptomsStep from "./components/AdditionalSymptomsStep";
import ResultsStepEnhanced from "./components/ResultsStepEnhanced";
import StepIndicator from "./components/StepIndicator";
import About from "./pages/About";
import TechStack from "./pages/TechStack";
import ProjectInfo from "./pages/ProjectInfo";
import { analyzeSymptomsData, type Diagnosis } from "./data/symptoms";
import { savePatientAndConsultation } from "./services/database";

type Step = 1 | 2 | 3 | 4 | 5;
type Page = "home" | "about" | "tech" | "project";

function AppContent() {
  const { isDark } = useTheme();
  const [currentPage, setCurrentPage] = useState<Page>("home");
  const [step, setStep] = useState<Step>(1);
  const [userName, setUserName] = useState("");
  const [userAge, setUserAge] = useState(0);
  const [selectedSymptoms, setSelectedSymptoms] = useState<string[]>([]);
  const [primaryText, setPrimaryText] = useState("");
  const [diagnosis, setDiagnosis] = useState<Diagnosis | null>(null);

  function handleLogin(name: string, age: number) {
    setUserName(name);
    setUserAge(age);
    setStep(2);
  }

  function handleSymptomsSubmit(ids: string[], text: string) {
    setSelectedSymptoms(ids);
    setPrimaryText(text);
    setStep(3);
  }

  function handleAnalysisContinue() {
    setStep(4);
  }

  async function handleAdditionalSymptoms(hasMore: boolean, additionalText: string) {
    const combinedText = [primaryText, additionalText].filter(Boolean).join(". ");
    const result = analyzeSymptomsData(selectedSymptoms, combinedText);
    setDiagnosis(result);

    await savePatientAndConsultation(
      { name: userName, age: userAge },
      {
        symptoms: selectedSymptoms,
        additional_notes: combinedText,
        analysis_results: result,
        severity: result.severity,
        risk_level: result.feverTypes[0]?.probability >= 70 ? "high" : result.feverTypes[0]?.probability >= 50 ? "medium" : "low",
      }
    );

    setStep(5);
  }

  function handleRestart() {
    setStep(1);
    setUserName("");
    setUserAge(0);
    setSelectedSymptoms([]);
    setPrimaryText("");
    setDiagnosis(null);
  }

  function handleNavigate(page: Page) {
    setCurrentPage(page);
    if (page === "home") {
      handleRestart();
    }
  }

  return (
    <div className={`min-h-screen ${isDark ? "bg-slate-900" : "bg-gradient-to-br from-slate-50 via-sky-50/30 to-cyan-50/40"}`}>
      <Header onNavigate={handleNavigate} currentPage={currentPage} />

      <main className="max-w-2xl lg:max-w-4xl mx-auto px-4 py-8">
        {currentPage === "home" && (
          <>
            {step > 1 && <StepIndicator currentStep={step} totalSteps={5} />}

            {step === 1 && <LoginStep onSubmit={handleLogin} />}
            {step === 2 && (
              <SymptomsStep
                userName={userName}
                userAge={userAge}
                onSubmit={handleSymptomsSubmit}
              />
            )}
            {step === 3 && <AnalysisStep onContinue={handleAnalysisContinue} />}
            {step === 4 && <AdditionalSymptomsStep onSubmit={handleAdditionalSymptoms} />}
            {step === 5 && diagnosis && (
              <ResultsStepEnhanced
                diagnosis={diagnosis}
                userName={userName}
                userAge={userAge}
                selectedSymptoms={selectedSymptoms}
                onRestart={handleRestart}
              />
            )}
          </>
        )}

        {currentPage === "about" && <About onBack={() => handleNavigate("home")} />}
        {currentPage === "tech" && <TechStack onBack={() => handleNavigate("home")} />}
        {currentPage === "project" && <ProjectInfo onBack={() => handleNavigate("home")} />}
      </main>

      {/* Footer */}
      <footer className={`${isDark ? "border-slate-800 bg-slate-800/50" : "border-slate-100 bg-white"} border-t mt-8 backdrop-blur-sm`}>
        <div className="max-w-2xl lg:max-w-4xl mx-auto px-4 py-6 text-center">
          <p className={`text-xs ${isDark ? "text-slate-400" : "text-slate-400"}`}>
            Nova Med AI — Intelligent Healthcare Analysis. For informational purposes only. Always consult a licensed doctor.
          </p>
          <p className={`text-xs ${isDark ? "text-slate-500" : "text-slate-500"} mt-2`}>
            © 2026 Nova Med AI. Built with React, TypeScript, and Supabase.
          </p>
        </div>
      </footer>
    </div>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <AppContent />
    </ThemeProvider>
  );
}
