import { useTheme } from "../context/ThemeContext";
import { ChevronLeft, Code2, Database, Zap, Boxes } from "lucide-react";

interface TechStackProps {
  onBack: () => void;
}

const techCategories = [
  {
    title: "Frontend Framework",
    icon: Code2,
    color: "text-blue-500",
    items: [
      { name: "React 18.3", description: "Modern UI library with hooks" },
      { name: "TypeScript", description: "Type-safe JavaScript development" },
      { name: "Vite", description: "Next-gen frontend build tool" },
      { name: "Tailwind CSS", description: "Utility-first CSS framework" },
    ],
  },
  {
    title: "Backend & Database",
    icon: Database,
    color: "text-emerald-500",
    items: [
      { name: "Supabase", description: "PostgreSQL-based backend" },
      { name: "PostgreSQL", description: "Reliable relational database" },
      { name: "Row Level Security", description: "Database-level access control" },
    ],
  },
  {
    title: "AI & Analytics",
    icon: Zap,
    color: "text-amber-500",
    items: [
      { name: "Custom ML Algorithm", description: "Symptom pattern matching" },
      { name: "Chart.js", description: "Beautiful data visualizations" },
      { name: "React-ChartJS-2", description: "React integration for charts" },
    ],
  },
  {
    title: "Utilities & Libraries",
    icon: Boxes,
    color: "text-violet-500",
    items: [
      { name: "jsPDF", description: "PDF report generation" },
      { name: "HTML2Canvas", description: "Screenshot to PDF conversion" },
      { name: "Lucide React", description: "Beautiful icon library" },
    ],
  },
];

export default function TechStack({ onBack }: TechStackProps) {
  const { isDark } = useTheme();

  return (
    <div className={`min-h-screen ${isDark ? "bg-slate-900" : "bg-gradient-to-br from-slate-50 via-sky-50/30 to-cyan-50/40"}`}>
      <div className="max-w-4xl mx-auto px-4 py-8">
        <button
          onClick={onBack}
          className={`flex items-center gap-2 mb-8 px-4 py-2 rounded-xl ${isDark ? "bg-slate-800 text-slate-300 hover:text-white" : "bg-white text-slate-600 hover:text-slate-800"} font-medium text-sm transition-colors`}
        >
          <ChevronLeft className="w-4 h-4" />
          Back to Symptom Check
        </button>

        <div className={`${isDark ? "bg-slate-800" : "bg-white"} rounded-2xl shadow-xl p-8 mb-8`}>
          <h1 className={`text-4xl font-bold mb-2 ${isDark ? "text-white" : "text-slate-800"}`}>
            Technology Stack
          </h1>
          <p className={`${isDark ? "text-slate-400" : "text-slate-500"} text-lg`}>
            Modern technologies powering Nova Med AI
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-6 mb-8">
          {techCategories.map((category) => {
            const Icon = category.icon;
            return (
              <div
                key={category.title}
                className={`${isDark ? "bg-slate-800" : "bg-white"} rounded-2xl shadow-xl p-6`}
              >
                <div className="flex items-center gap-3 mb-4">
                  <div className={`p-2 rounded-lg ${isDark ? "bg-slate-700" : "bg-slate-100"}`}>
                    <Icon className={`w-6 h-6 ${category.color}`} />
                  </div>
                  <h3 className={`text-lg font-bold ${isDark ? "text-white" : "text-slate-800"}`}>
                    {category.title}
                  </h3>
                </div>
                <ul className="space-y-3">
                  {category.items.map((item) => (
                    <div key={item.name} className={`p-3 rounded-lg ${isDark ? "bg-slate-700/50" : "bg-slate-50"}`}>
                      <p className={`font-semibold text-sm ${isDark ? "text-slate-200" : "text-slate-700"}`}>
                        {item.name}
                      </p>
                      <p className={`text-xs ${isDark ? "text-slate-400" : "text-slate-500"} mt-0.5`}>
                        {item.description}
                      </p>
                    </div>
                  ))}
                </ul>
              </div>
            );
          })}
        </div>

        <div className={`${isDark ? "bg-slate-800" : "bg-white"} rounded-2xl shadow-xl p-8`}>
          <h2 className={`text-2xl font-bold mb-4 ${isDark ? "text-white" : "text-slate-800"}`}>
            Architecture Highlights
          </h2>
          <div className="space-y-4">
            <div>
              <h4 className={`font-semibold ${isDark ? "text-sky-400" : "text-sky-600"} mb-2`}>Responsive Design</h4>
              <p className={`text-sm ${isDark ? "text-slate-400" : "text-slate-600"}`}>
                Mobile-first approach using Tailwind CSS for seamless experience across all devices
              </p>
            </div>
            <div>
              <h4 className={`font-semibold ${isDark ? "text-emerald-400" : "text-emerald-600"} mb-2`}>Secure Backend</h4>
              <p className={`text-sm ${isDark ? "text-slate-400" : "text-slate-600"}`}>
                PostgreSQL with Supabase RLS policies for enterprise-grade data protection
              </p>
            </div>
            <div>
              <h4 className={`font-semibold ${isDark ? "text-amber-400" : "text-amber-600"} mb-2`}>Real-time Analytics</h4>
              <p className={`text-sm ${isDark ? "text-slate-400" : "text-slate-600"}`}>
                Live tracking of symptom patterns and medical condition predictions
              </p>
            </div>
            <div>
              <h4 className={`font-semibold ${isDark ? "text-violet-400" : "text-violet-600"} mb-2`}>Dark Mode Support</h4>
              <p className={`text-sm ${isDark ? "text-slate-400" : "text-slate-600"}`}>
                Native dark mode implementation with system preference detection
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
