import { useTheme } from "../context/ThemeContext";
import { ChevronLeft, Heart, Zap, Shield, Users } from "lucide-react";

interface AboutProps {
  onBack: () => void;
}

export default function About({ onBack }: AboutProps) {
  const { isDark } = useTheme();

  return (
    <div className={`min-h-screen ${isDark ? "bg-slate-900" : "bg-gradient-to-br from-slate-50 via-sky-50/30 to-cyan-50/40"}`}>
      <div className="max-w-4xl mx-auto px-4 py-8">
        <button
          onClick={onBack}
          className={`flex items-center gap-2 mb-8 px-4 py-2 rounded-xl ${isDark ? "bg-slate-800 text-slate-300 hover:text-white" : "bg-white text-slate-600 hover:text-slate-800"} font-medium text-sm transition-colors`}
        >
          <ChevronLeft className="w-4 h-4" />
          Back to Symptom Check
        </button>

        <div className={`${isDark ? "bg-slate-800" : "bg-white"} rounded-2xl shadow-xl p-8 mb-6`}>
          <h1 className={`text-4xl font-bold mb-2 ${isDark ? "text-white" : "text-slate-800"}`}>
            About Nova Med AI
          </h1>
          <p className={`${isDark ? "text-slate-400" : "text-slate-500"} text-lg`}>
            Intelligent Medical Symptom Analysis for Everyone
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-6 mb-8">
          <div className={`${isDark ? "bg-slate-800" : "bg-white"} rounded-2xl shadow-xl p-6`}>
            <Heart className={`w-8 h-8 mb-3 ${isDark ? "text-red-400" : "text-red-500"}`} />
            <h3 className={`text-lg font-bold mb-2 ${isDark ? "text-white" : "text-slate-800"}`}>Our Mission</h3>
            <p className={`${isDark ? "text-slate-400" : "text-slate-600"} text-sm leading-relaxed`}>
              To democratize healthcare access by providing AI-powered symptom analysis that helps users understand their health conditions better and make informed decisions about seeking professional medical care.
            </p>
          </div>

          <div className={`${isDark ? "bg-slate-800" : "bg-white"} rounded-2xl shadow-xl p-6`}>
            <Zap className={`w-8 h-8 mb-3 ${isDark ? "text-amber-400" : "text-amber-500"}`} />
            <h3 className={`text-lg font-bold mb-2 ${isDark ? "text-white" : "text-slate-800"}`}>Technology</h3>
            <p className={`${isDark ? "text-slate-400" : "text-slate-600"} text-sm leading-relaxed`}>
              Built with advanced machine learning algorithms that analyze symptom patterns against a comprehensive medical database to provide accurate probability assessments of possible conditions.
            </p>
          </div>

          <div className={`${isDark ? "bg-slate-800" : "bg-white"} rounded-2xl shadow-xl p-6`}>
            <Shield className={`w-8 h-8 mb-3 ${isDark ? "text-emerald-400" : "text-emerald-500"}`} />
            <h3 className={`text-lg font-bold mb-2 ${isDark ? "text-white" : "text-slate-800"}`}>Privacy & Security</h3>
            <p className={`${isDark ? "text-slate-400" : "text-slate-600"} text-sm leading-relaxed`}>
              Your health data is treated with utmost confidentiality. All patient information is encrypted and stored securely, following HIPAA and international healthcare data protection standards.
            </p>
          </div>

          <div className={`${isDark ? "bg-slate-800" : "bg-white"} rounded-2xl shadow-xl p-6`}>
            <Users className={`w-8 h-8 mb-3 ${isDark ? "text-blue-400" : "text-blue-500"}`} />
            <h3 className={`text-lg font-bold mb-2 ${isDark ? "text-white" : "text-slate-800"}`}>For Everyone</h3>
            <p className={`${isDark ? "text-slate-400" : "text-slate-600"} text-sm leading-relaxed`}>
              Nova Med AI is designed for everyone — from individuals seeking health information to busy professionals who need quick symptom assessment before visiting a doctor.
            </p>
          </div>
        </div>

        <div className={`${isDark ? "bg-slate-800" : "bg-white"} rounded-2xl shadow-xl p-8`}>
          <h2 className={`text-2xl font-bold mb-4 ${isDark ? "text-white" : "text-slate-800"}`}>Key Features</h2>
          <ul className={`space-y-3 ${isDark ? "text-slate-400" : "text-slate-600"}`}>
            <li className="flex items-start gap-3">
              <span className={`${isDark ? "text-sky-400" : "text-sky-500"} font-bold flex-shrink-0`}>✓</span>
              <span>Multi-symptom analysis with AI-powered probability calculations</span>
            </li>
            <li className="flex items-start gap-3">
              <span className={`${isDark ? "text-sky-400" : "text-sky-500"} font-bold flex-shrink-0`}>✓</span>
              <span>Fever type detection covering 10+ medical conditions</span>
            </li>
            <li className="flex items-start gap-3">
              <span className={`${isDark ? "text-sky-400" : "text-sky-500"} font-bold flex-shrink-0`}>✓</span>
              <span>Personalized health recommendations and precautions</span>
            </li>
            <li className="flex items-start gap-3">
              <span className={`${isDark ? "text-sky-400" : "text-sky-500"} font-bold flex-shrink-0`}>✓</span>
              <span>Downloadable PDF reports for medical reference</span>
            </li>
            <li className="flex items-start gap-3">
              <span className={`${isDark ? "text-sky-400" : "text-sky-500"} font-bold flex-shrink-0`}>✓</span>
              <span>Dark mode support for comfortable usage</span>
            </li>
            <li className="flex items-start gap-3">
              <span className={`${isDark ? "text-sky-400" : "text-sky-500"} font-bold flex-shrink-0`}>✓</span>
              <span>Consultation history tracking and analytics</span>
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
}
