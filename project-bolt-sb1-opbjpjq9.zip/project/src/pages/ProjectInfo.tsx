import { useTheme } from "../context/ThemeContext";
import { ChevronLeft, Target, Lightbulb, BookOpen, BarChart3 } from "lucide-react";

interface ProjectInfoProps {
  onBack: () => void;
}

export default function ProjectInfo({ onBack }: ProjectInfoProps) {
  const { isDark } = useTheme();

  return (
    <div className={`min-h-screen ${isDark ? "bg-slate-900" : "bg-gradient-to-br from-slate-50 via-sky-50/30 to-cyan-50/40"}`}>
      <div className="max-w-4xl mx-auto px-4 py-8">
        <button
          onClick={onBack}
          className={`flex items-center gap-2 mb-8 px-4 py-2 rounded-xl ${isDark ? "bg-slate-800 text-slate-300 hover:text-white" : "bg-white text-slate-600 hover:text-slate-800"} font-medium text-sm transition-colors`}
        >
          <ChevronLeft className="w-4 h-4" />
          Back to Symptom Check
        </button>

        <div className={`${isDark ? "bg-slate-800" : "bg-white"} rounded-2xl shadow-xl p-8 mb-8`}>
          <h1 className={`text-4xl font-bold mb-2 ${isDark ? "text-white" : "text-slate-800"}`}>
            Project Overview
          </h1>
          <p className={`${isDark ? "text-slate-400" : "text-slate-500"} text-lg`}>
            Engineering Excellence in Healthcare AI
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-6 mb-8">
          <div className={`${isDark ? "bg-slate-800" : "bg-white"} rounded-2xl shadow-xl p-6`}>
            <Target className={`w-8 h-8 mb-3 ${isDark ? "text-red-400" : "text-red-500"}`} />
            <h3 className={`text-lg font-bold mb-2 ${isDark ? "text-white" : "text-slate-800"}`}>Objectives</h3>
            <ul className={`space-y-2 text-sm ${isDark ? "text-slate-400" : "text-slate-600"}`}>
              <li>• Develop AI-powered medical symptom analyzer</li>
              <li>• Implement secure patient data management</li>
              <li>• Create intuitive healthcare interface</li>
              <li>• Enable PDF report generation</li>
              <li>• Support multi-device compatibility</li>
            </ul>
          </div>

          <div className={`${isDark ? "bg-slate-800" : "bg-white"} rounded-2xl shadow-xl p-6`}>
            <Lightbulb className={`w-8 h-8 mb-3 ${isDark ? "text-amber-400" : "text-amber-500"}`} />
            <h3 className={`text-lg font-bold mb-2 ${isDark ? "text-white" : "text-slate-800"}`}>Key Innovations</h3>
            <ul className={`space-y-2 text-sm ${isDark ? "text-slate-400" : "text-slate-600"}`}>
              <li>• Advanced symptom pattern matching</li>
              <li>• 10+ fever type detection</li>
              <li>• Real-time risk assessment</li>
              <li>• Dark mode interface</li>
              <li>• Glassmorphism design</li>
            </ul>
          </div>
        </div>

        <div className={`${isDark ? "bg-slate-800" : "bg-white"} rounded-2xl shadow-xl p-8 mb-8`}>
          <div className="flex items-center gap-3 mb-4">
            <BookOpen className={`w-6 h-6 ${isDark ? "text-sky-400" : "text-sky-500"}`} />
            <h2 className={`text-2xl font-bold ${isDark ? "text-white" : "text-slate-800"}`}>
              Methodology
            </h2>
          </div>
          <div className={`space-y-4 ${isDark ? "text-slate-400" : "text-slate-600"} text-sm leading-relaxed`}>
            <div>
              <p className={`font-semibold ${isDark ? "text-slate-300" : "text-slate-700"} mb-1`}>1. Symptom Collection</p>
              <p>Users select from 20+ common symptoms with optional free-text descriptions for better accuracy</p>
            </div>
            <div>
              <p className={`font-semibold ${isDark ? "text-slate-300" : "text-slate-700"} mb-1`}>2. Pattern Analysis</p>
              <p>Machine learning algorithm analyzes symptom combinations against medical condition databases</p>
            </div>
            <div>
              <p className={`font-semibold ${isDark ? "text-slate-300" : "text-slate-700"} mb-1`}>3. Risk Assessment</p>
              <p>Calculates probability percentages for different fever types and medical conditions</p>
            </div>
            <div>
              <p className={`font-semibold ${isDark ? "text-slate-300" : "text-slate-700"} mb-1`}>4. Recommendation Generation</p>
              <p>Generates personalized health suggestions, precautions, and medicine information</p>
            </div>
            <div>
              <p className={`font-semibold ${isDark ? "text-slate-300" : "text-slate-700"} mb-1`}>5. Report Generation</p>
              <p>Creates comprehensive PDF reports with all analysis data for medical reference</p>
            </div>
          </div>
        </div>

        <div className={`${isDark ? "bg-slate-800" : "bg-white"} rounded-2xl shadow-xl p-8`}>
          <div className="flex items-center gap-3 mb-4">
            <BarChart3 className={`w-6 h-6 ${isDark ? "text-emerald-400" : "text-emerald-500"}`} />
            <h2 className={`text-2xl font-bold ${isDark ? "text-white" : "text-slate-800"}`}>
              Performance Metrics
            </h2>
          </div>
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <p className={`text-3xl font-bold ${isDark ? "text-sky-400" : "text-sky-600"}`}>20+</p>
              <p className={`text-sm ${isDark ? "text-slate-400" : "text-slate-600"} mt-1`}>Symptom Types</p>
            </div>
            <div>
              <p className={`text-3xl font-bold ${isDark ? "text-emerald-400" : "text-emerald-600"}`}>10+</p>
              <p className={`text-sm ${isDark ? "text-slate-400" : "text-slate-600"} mt-1`}>Fever Type Detections</p>
            </div>
            <div>
              <p className={`text-3xl font-bold ${isDark ? "text-amber-400" : "text-amber-600"}`}>100%</p>
              <p className={`text-sm ${isDark ? "text-slate-400" : "text-slate-600"} mt-1`}>Mobile Responsive</p>
            </div>
            <div>
              <p className={`text-3xl font-bold ${isDark ? "text-violet-400" : "text-violet-600"}`}>{"<1s"}</p>
              <p className={`text-sm ${isDark ? "text-slate-400" : "text-slate-600"} mt-1`}>Analysis Time</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
