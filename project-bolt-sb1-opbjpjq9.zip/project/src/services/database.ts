import { createClient, type SupabaseClient } from "@supabase/supabase-js";
import { Diagnosis } from "../data/symptoms";

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseKey) {
  console.warn("Supabase credentials not found");
}

const supabase: SupabaseClient | null = supabaseUrl && supabaseKey ? createClient(supabaseUrl, supabaseKey) : null;

let isAuthenticating = false;
let authPromise: Promise<void> | null = null;

export async function ensureAuthenticated(): Promise<string | null> {
  if (!supabase) return null;

  const { data: { session } } = await supabase.auth.getSession();
  if (session?.user) return session.user.id;

  if (isAuthenticating && authPromise) {
    await authPromise;
    const { data: { user: u } } = await supabase.auth.getUser();
    return u?.id ?? null;
  }

  isAuthenticating = true;
  authPromise = (async () => {
    const { error } = await supabase.auth.signInAnonymously();
    if (error) throw error;
  })();

  try {
    await authPromise;
    const { data: { user: u } } = await supabase.auth.getUser();
    return u?.id ?? null;
  } finally {
    isAuthenticating = false;
    authPromise = null;
  }
}

export async function getCurrentUserId(): Promise<string | null> {
  if (!supabase) return null;
  const { data: { user } } = await supabase.auth.getUser();
  return user?.id ?? null;
}

export interface Patient {
  id?: string;
  name: string;
  age: number;
  email?: string;
  phone?: string;
  medical_history?: string;
  created_at?: string;
  user_id?: string;
}

export interface Consultation {
  id?: string;
  patient_id: string;
  symptoms: string[];
  additional_notes: string;
  analysis_results: Diagnosis;
  severity: string;
  risk_level: string;
  created_at?: string;
  user_id?: string;
}

export async function savePatientAndConsultation(
  patient: Patient,
  consultation: Omit<Consultation, "patient_id">
): Promise<{ patientId: string; consultationId: string } | null> {
  if (!supabase) return null;

  try {
    const userId = await ensureAuthenticated();
    if (!userId) throw new Error("Unable to authenticate user");

    const { data: patientData, error: patientError } = await supabase
      .from("patients")
      .insert([{ ...patient, user_id: userId }])
      .select("id")
      .single();

    if (patientError) throw patientError;

    const { data: consultationData, error: consultationError } = await supabase
      .from("consultations")
      .insert([
        {
          ...consultation,
          patient_id: patientData.id,
          user_id: userId,
        },
      ])
      .select("id")
      .single();

    if (consultationError) throw consultationError;

    return {
      patientId: patientData.id,
      consultationId: consultationData.id,
    };
  } catch (error) {
    console.error("Error saving patient and consultation:", error);
    return null;
  }
}

export async function getPatientConsultations(
  patientId: string
): Promise<Consultation[]> {
  if (!supabase) return [];

  try {
    await ensureAuthenticated();
    const { data, error } = await supabase
      .from("consultations")
      .select("*")
      .eq("patient_id", patientId)
      .order("created_at", { ascending: false });

    if (error) throw error;
    return data || [];
  } catch (error) {
    console.error("Error fetching consultations:", error);
    return [];
  }
}

export async function getCommonSymptoms(): Promise<
  Array<{ symptom_name: string; count: number }>
> {
  if (!supabase) return [];

  try {
    const { data, error } = await supabase
      .from("symptom_analytics")
      .select("symptom_name, count")
      .order("count", { ascending: false })
      .limit(10);

    if (error) throw error;
    return data || [];
  } catch (error) {
    console.error("Error fetching symptom analytics:", error);
    return [];
  }
}

export async function updateSymptomAnalytics(
  symptoms: string[]
): Promise<void> {
  if (!supabase) return;

  try {
    await ensureAuthenticated();
    for (const symptom of symptoms) {
      const { data: existing } = await supabase
        .from("symptom_analytics")
        .select("count")
        .eq("symptom_name", symptom)
        .single();

      if (existing) {
        await supabase
          .from("symptom_analytics")
          .update({ count: existing.count + 1 })
          .eq("symptom_name", symptom);
      } else {
        await supabase
          .from("symptom_analytics")
          .insert([{ symptom_name: symptom, count: 1 }]);
      }
    }
  } catch (error) {
    console.error("Error updating symptom analytics:", error);
  }
}
